Open the full documentation in the toolbar of the unity-editor:
Window -> CustomInspector Documentation